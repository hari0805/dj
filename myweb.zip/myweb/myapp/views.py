# importing the necessary libraries for html to pdf
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa
from django.views.generic import View
from django.template.loader import render_to_string
from myapp import models

# importing for formview
from django.views.generic.edit import FormView
from .forms import Myform

# Create your views here.

class MyFormView(FormView):
    template_name = 'form1.html'
    form_class = Myform
    success_url = 'pdf/'

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)       


# Creating a Cless to Generate pdf
class GeneratePdf(View):

    def html_to_pdf(self, template_src, context_dict={}):
        template = get_template(template_src)
        html  = template.render(context_dict)
        result = BytesIO()
        pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
        if not pdf.err:
            return HttpResponse(result.getvalue(), content_type='application/pdf')
        return None

    def get(self, request, *args, **kwargs):
        data = models.Mydb.objects.last()

        open('templates/temp.html', "w").write(render_to_string('result.html', {'data':data}))

        # Converting the HTML template into a PDF file
        pdf = self.html_to_pdf('temp.html')
         
        # rendering the template
        return HttpResponse(pdf, content_type='application/pdf')