from django.db import models
from django.utils import timezone

# Create your models here.

# class EventManager(models.Manager):

#     def get_queryset(self):
#         return super().get_queryset().filter(
#             publishing_date=timezone.now()-timezone.timedelta(minutes=5)
#         )

# Creating class for our Table

class Mydb(models.Model):
    Name = models.CharField(max_length=100)
    City = models.CharField(max_length=100)
    Degree = models.CharField(max_length=100)
    College = models.CharField(max_length=100)
    Hobby = models.CharField(max_length=100)
    Language = models.CharField(max_length=100)
    # publishing_date = models.DateTimeField(default=timezone.now,blank=True,)

    # Remove_ = EventManager()

    # @staticmethod
    # def delete_old():
    #     Mydb.Remove_.filter(
    #         publishing_date__lt=timezone.now()-timezone.timedelta(minutes=5)
    #     ).delete()
