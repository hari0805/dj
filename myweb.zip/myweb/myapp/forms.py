#from pyexpat import model
from django.forms import ModelForm
from myapp.models import Mydb

class Myform(ModelForm):
    class Meta:
        model = Mydb
        fields = '__all__'
        #exclude = ['publishing_date']

