from django.urls import path
from .views import *
#from .forms import *

urlpatterns = [
    path('', MyFormView.as_view(), name="home"),
    path('pdf/', GeneratePdf.as_view(), name="GeneratePdf"),
]